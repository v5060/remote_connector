This Project simply aims for 
To connect to remote servers via SFTP, Telnet, and SSH. 
Implement functionalities for executing commands based on the provided inputs.

it has one Base Connector where we have used
abstract methods which is required for all the types of connections

we are useing Paramiko module for SFTP and SSH

and telnetlib for telnet connection

we have used basic commands based on user input